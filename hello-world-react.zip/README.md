
# Hello World React App

This is a simple React app built using Vite. It displays a "Hello World" message as part of the 3MTT Mini Project.

## How to Run

1. Install dependencies:

```bash
npm install
```

2. Start development server:

```bash
npm run dev
```
